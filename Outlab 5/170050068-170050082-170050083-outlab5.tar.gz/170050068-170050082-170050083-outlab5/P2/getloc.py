#! /usr/bin/python
import requests
import datetime
def iss_location():
    response = requests.get('http://api.open-notify.org/iss-now.json')
    data = response.json()
    latitude = data['iss_position']['latitude']
    longitude = data['iss_position']['longitude']
    print('Current Location of ISS:')
    print('Latitude : '+latitude)
    print('Longitude : '+longitude)
iss_location()
print("Enter Details to know when ISS will pass over a location:")
arg1=input("Latitude : ")
arg2=input("Longitude : ")

def pass_time(arg1,arg2):
    parameters={'lat':arg1,'lon':arg2}
    r=requests.get('http://api.open-notify.org/iss-pass.json?lat=45.0&lon=-122.3',params=parameters)
    data=r.json()
    d=data['response'][0]['risetime']
    print("Date :",datetime.datetime.fromtimestamp(int(d)).strftime('%d/%m/%Y'))
    print("Time :",datetime.datetime.fromtimestamp(int(d)).strftime('%H:%M'))
    duration=data['response'][0]['duration']
    print("For :",(int(duration)//60),"minutes and",(int(duration)%60),"seconds")
def people_info():
    k=1
    response=requests.get('http://api.open-notify.org/astros.json')
    data=response.json()
    number=data['number']
    print('People currently in space:'+str(number))
    for i in data['people']:
        print(str(k)+"."+i['name'])
        k+=1
pass_time(arg1,arg2) 
people_info()       