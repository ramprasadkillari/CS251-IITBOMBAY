#! /usr/bin/python
import sqlite3
import csv
conn = sqlite3.connect('cse_students.sqlite')
c = conn.cursor()
p=[]
c.execute("DROP TABLE IF EXISTS tbl")
# Create table
c.execute('''CREATE TABLE tbl
             ("Category Name" text, "No. of students" int)''')

f=csv.reader(open("count.csv","r"),delimiter="\t")
i=0
for k in f:
    if(i>0):
        p.append((k[0],int(k[1])))
    else:
        i+=1
# Save (commit) the changes
c.executemany("INSERT INTO tbl VALUES (?,?)",p)

conn.commit()


n=input("Enter category name :")
def returncount(n):
    c.execute('SELECT * FROM tbl')
    for row in c.fetchall():
        if(n==row[0]):
            return row[1]
    return "INVALID"
print(returncount(n))            
conn.close()
