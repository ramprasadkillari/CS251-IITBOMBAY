#! /usr/bin/python
import requests
import json
import urllib.request
from bs4 import BeautifulSoup
import csv
from itertools import zip_longest
url='https://www.cse.iitb.ac.in/page222'
list1=[]
list2=[]
list3=[]
list4=[]
r=requests.get(url)
soup=BeautifulSoup(r.text,'html.parser')
productDivs=soup.findAll('div', attrs={'class' : 'mpart'})
for data in productDivs:
    for a in data.find_all('a'):
        b=a.get('href')
        list1.append(requests.get(url+b))
        list3.append(a.text)

for j in list1:       
    soup2=BeautifulSoup(j.text,'html.parser')
    PDs=soup2.findAll('table', attrs={'border' : '0', 'width' : '100%'})
    for d in PDs:
        for c in d.find_all('a'):
            list2.append(c.text)
            
        list4.append(len(list2)//2)    
        list2=[]

pen=csv.writer(open("count.csv","w"),delimiter="\t")
pen.writerow(["Category Name","No. of students"])
for i in range(len(list3)):
    pen.writerow([list3[i],list4[i]])

       
