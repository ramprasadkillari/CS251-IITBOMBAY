#include<iostream>
using namespace std;
class snake{
	public:
	int length;
	int venom;
	
	int venomsq();
	int lengthsq();

};