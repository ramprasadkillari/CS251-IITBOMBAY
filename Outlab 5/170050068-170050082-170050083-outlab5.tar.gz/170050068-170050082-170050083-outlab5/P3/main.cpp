#include "depend.h"
using namespace std;
int main(){
	int x=2,y=3;
	snake ram;
	ram.length=x;
	ram.venom=y;
	cout<<ram.lengthsq()<<endl;
}