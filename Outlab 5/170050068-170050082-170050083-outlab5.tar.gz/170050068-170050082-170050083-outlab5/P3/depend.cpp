#include "depend.h"
int snake::lengthsq(){return length*length;}
int snake::venomsq(){return venom*venom;}