package com.example.ramprasad.outlab9;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {

    static EditText key;
    static List<String> list_usernames;
    static final String API_URL = "https://api.github.com/";
    ProgressBar progressBar;
    Button button;
    ArrayAdapter<String> adapter;
    ListView listView;
    AsyncTaskRunner myAsyncTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        key =findViewById(R.id.key);
        list_usernames = new ArrayList<String>();
        button = (Button) findViewById(R.id.queryButton);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list_usernames);
        listView = findViewById(R.id.listview);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                list_usernames.clear();
                listView.invalidateViews();

                String k = key.getText().toString();

                // Hide the keyboard when the button is pushed.
                InputMethodManager inputManager = (InputMethodManager)
                        getSystemService(Context.INPUT_METHOD_SERVICE);
                inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
                        InputMethodManager.HIDE_NOT_ALWAYS);

                // Check the status of the network connection.
                ConnectivityManager connMgr = (ConnectivityManager)
                        getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

                // If the network is active and the search field is not empty, start a FetchBook AsyncTask.
                if (networkInfo != null && networkInfo.isConnected() && k.length()!=0) {

                    myAsyncTask = new AsyncTaskRunner();
                myAsyncTask.execute();
                }
                // Otherwise update the TextView to tell the user there is no connection or no search term.
                else {
                    if (k.length() == 0) {
                        Toast toast1 = Toast.makeText(getApplicationContext(),
                                "Please enter Username!!",
                                Toast.LENGTH_SHORT);
                        toast1.show();
                    } else {
                        Toast toast1 = Toast.makeText(getApplicationContext(),
                                "No Connection!!",
                                Toast.LENGTH_SHORT);
                        toast1.show();
                    }
                }
            }
        });


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = (String) listView.getItemAtPosition(position);
                Intent i = new Intent(SearchActivity.this, UserActivity.class);
                i.putExtra("user", item);
                startActivity(i);
            }
        });
    }
    private class AsyncTaskRunner extends AsyncTask<Void, Void, List<String> > {

        @Override
        protected List<String> doInBackground(Void... urls) {
            String k = key.getText().toString();
            try {
                URL url = new URL(API_URL + "search/users?" + "q=" + k + "&" + "sort=repositories" + "&" + "order=desc");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    String result = stringBuilder.toString();
                    try {
                        JSONObject jo = new JSONObject(result);
                        JSONArray jr = (JSONArray) jo.getJSONArray("items");
                        for (int i = 0; i < jr.length(); i++) {
                            JSONObject st = jr.getJSONObject(i);
                            String username = st.getString("login");
                            list_usernames.add(username);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    return list_usernames;
                } finally {
                    if (urlConnection != null) {
                        urlConnection.disconnect();
                    }
                    }
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                return null;
            }
        }


        protected void onPostExecute(List<String> response) {
            progressBar.setVisibility(View.GONE);
        if (response.isEmpty()) {
            Toast toast1 = Toast.makeText(getApplicationContext(),
                    "No Results Found!!",
                    Toast.LENGTH_SHORT);
            toast1.show();

        }
        else if (response == null) {
                Toast toast1 = Toast.makeText(getApplicationContext(),
                        "No Results Found!!",
                        Toast.LENGTH_SHORT);
                toast1.show();
            }
         else {

                try {
                    listView.setAdapter(adapter);
                    Toast toast1 = Toast.makeText(getApplicationContext(),
                            "Completed Search",
                            Toast.LENGTH_SHORT);

                    toast1.show();
                } catch (Exception e) {
                    Toast toast1 = Toast.makeText(getApplicationContext(),
                            "Error!!",
                            Toast.LENGTH_SHORT);
                    toast1.show();
                }
            }
        }

        @Override
        protected void onPreExecute() {
            progressBar.setVisibility(View.VISIBLE);
        }
    }
}