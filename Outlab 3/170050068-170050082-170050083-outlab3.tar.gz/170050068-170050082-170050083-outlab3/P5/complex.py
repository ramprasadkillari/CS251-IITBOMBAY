#! /usr/bin/python
file = open("numbers.txt")
line1 = file.readline().split()
a1 = int (line1[0])
b1=int (line1[1])
line2=file.readline().split()
a2 = int (line2[0])
b2 = int (line2[1])

class Complex():
	def __init__(self,r,i):
		self.real = r
		self.imag = i
	def __str__(self):
		if self.imag < 0:
			print(self.real,self.imag,"i",sep="")
		else:
			print(self.real,"+",self.imag,"i",sep="")
	def __add__(self,comp):
		return Complex(self.real+comp.real,self.imag+comp.imag)
	def __sub__(self,comp):
		return Complex(self.real-comp.real,self.imag-comp.imag) 
	def __mult__(self,comp):
		a1 = self.real
		b1 = self.imag
		a2 = comp.real
		b2 = comp.imag
		return Complex(a1*a2-b1*b2,a1*b2+a2*b1)
	def __truediv__(self,comp):
		a1 = self.real
		b1 = self.imag
		a2 = comp.real
		b2 = comp.imag 
		norm = a2*a2+b2*b2
		return Complex((a1*a2+b1*b2)/norm,(a2*b1-a1*b2)/norm)
c1 = Complex(a1,b1)
c2= Complex(a2,b2)
a = c1.__add__(c2)
s = c1.__sub__(c2)
m = c1.__mult__(c2)
td = c1.__truediv__(c2)
c1.__str__()
c2.__str__()
a.__str__()
s.__str__()
m.__str__()
td.__str__()




