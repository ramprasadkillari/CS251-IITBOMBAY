#! /usr/bin/python
file=open("employees.txt")
for line in file:
    words=line.split()[0]
    print(words[3:],words[0:3],sep="")
    
   

