#! /usr/bin/python

mylist = []
file=open("students.txt")
number=int (file.readline())
for i in range(1,number+1):
	g=file.readline().split()
	x = g[0]
	y = g[1]
	dict = {x: y}
	mylist.append(dict)

loc= input("> ").split()
r1 = int (loc[0])
r2 = int (loc[1])
r3 = int (loc[2])
r4 = int (loc[3])


def find_total(x1,y1,x2,y2):
	count = 0
	if x1 == x2:
		for i in mylist:
			for it in i.items():
				x = int (it[0])
				y = int (it[1])
				if x==x1 :
					count+=1
				else: 
					count+=0
		return count
	else:    
		m= (y2 -y1)/(x2 - x1)
		for i in mylist:
			for it in i.items():
				x = int (it[0])
				y = int (it[1])
				if (x==x1 and y==y1):
					count+=1
				elif (y - y1)/(x - x1) == m:
					count+=1
				else: 
					count+=0
		return count
print(find_total(r1,r2,r3,r4)) 






