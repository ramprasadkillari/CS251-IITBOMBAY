#! /usr/bin/python
mylist = []
file=open("students.txt")
number=int (file.readline())
for i in range(1,number+1):
	g=file.readline().split()
	x = g[0]
	y = g[1]
	dict = {x: y}
	mylist.append(dict)
loc= input("> ").split()
r1 = int (loc[0])
r2 = int (loc[1])
r3 = int (loc[2])
r4 = int (loc[3])

def find_loc(x1,y1,x2,y2):
	if (x1 > x2 or y1 > y2):
		return -1
	else:
	    return x2 - x1 + y2 - y1

print(find_loc(r1,r2,r3,r4))	    	

