#! /usr/bin/python
snakelist = []
class Snake():
	def __init__(self,name,length,venom):
		self.name = name
		self.length = length
		self.venom = venom


def snake(name,length,venom):
	snakelist.append(Snake(name,length,venom))
def findByVenom(Venom):
	for sn in snakelist:
		if sn.venom == Venom:
			print(sn.name)
def	findByLength(Length):
	for sn in snakelist:
		if sn.length == Length:
			print(sn.name)

file=open("snakes.txt")
line=int(file.readline())
for i in range (1,line+1):
	info=file.readline().split()
	name=info[0]
	length=info[1]
	venom=info[2]
	snakelist.append(Snake(name,length,venom))
queries=int (file.readline())
for i in range(1,queries+1):
    info=file.readline().split()
    quer=info[0]
    val=info[1]
    if quer == "V":
    	findByVenom(val)
    else:
        findByLength(val)



  
