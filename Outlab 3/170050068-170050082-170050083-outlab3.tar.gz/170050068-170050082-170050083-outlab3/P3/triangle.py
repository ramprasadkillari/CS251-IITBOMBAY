#! /usr/bin/python

def area(x1,y1,x2,y2,x3,y3):
    return (abs(x1*(y2-y3)+x2*(y3-y1)+x3*(y1-y2))/2.0)


def insideOut():
    first  = input("Enter the first coordinate : ").split()
    second = input("Enter the second coordinate : ").split()
    third = input("Enter the third coordinates : ").split()
    key  = input("Enter coordinates of the key : ").split()
    x1 = int (first[0])
    y1 = int (first[1])
    x2 = int (second[0])
    y2 = int (second[1])
    x3 = int (third[0])
    y3 = int (third[1])
    x4 = float (key[0])
    y4 = float (key[1])
    net = (area(x1,y1,x4,y4,x3,y3) + area(x1,y1,x2,y2,x4,y4) + area(x4,y4,x2,y2,x3,y3))
    if area(x1,y1,x2,y2,x3,y3) == net :
        print("INSIDE")
    else:
        print("OUTSIDE")

insideOut()


 

 
    
