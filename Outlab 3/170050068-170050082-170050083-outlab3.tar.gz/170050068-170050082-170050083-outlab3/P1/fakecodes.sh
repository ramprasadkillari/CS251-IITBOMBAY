#! /bin/bash

var=$(cat /dev/urandom | tr -dc 'A-Z0-9' | fold -w 3 | head -n 1)

sed -e "s/[A-Z][A-Z][0-9]/$var/g" $1

