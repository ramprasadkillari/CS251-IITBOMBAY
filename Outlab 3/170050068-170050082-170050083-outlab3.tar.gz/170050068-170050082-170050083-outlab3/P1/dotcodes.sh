#! /bin/bash

sed -e "s/[A-Z][A-Z][0-9]/***/g" $1
