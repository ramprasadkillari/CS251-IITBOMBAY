$("#fsl").css("background-color", "red");
$("#fsl").css("color", "blue");
$("#fol li").each(function() {
	$(this).append(" in the list!");
});
$("body").css("background-color", '#eee');
$("a").click(function() {
	alert("You have clicked a link");
});
//added an id "fsl" to the first sublist under text
//added id "fol" to first ordered list