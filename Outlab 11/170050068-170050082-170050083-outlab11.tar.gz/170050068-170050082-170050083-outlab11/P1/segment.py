import numpy as np
from scipy.misc import imsave, imread
from sys import argv
param = argv[1]
if param == "eu" or param == "man":
    sea1 = imread("sea1.png")
    sea2 = imread("sea2.png")
    sea3 = imread("sea3.png")
    veg1 = imread("vegetation1.png")
    veg2 = imread("vegetation2.png")
    veg3 = imread("vegetation3.png")
    veg4 = imread("vegetation4.png")
    lake = imread("lake.png")
    buil = imread("builtup.png")
    mumb = imread("mumbai.png")

    def tot(img, l, b):
        res = np.zeros((1, 3))
        for i in range(l):
            for j in range(b):
                res += img[i, j]
        return res


    def dist(p1, p2):
        x1 = p1[0]
        x2 = p1[1]
        x3 = p1[2]
        y1 = p2[0]
        y2 = p2[1]
        y3 = p2[2]
        if param == "eu":
            return (x1 - y1) ** 2 + (x2 - y2) ** 2 + (x3 - y3) ** 2
        else:
            return abs(x1 - y1) + abs(x2 - y2) + abs(x3 - y3)


    l1, b1, c = sea1.shape
    l2, b2, c = sea2.shape
    l3, b3, c = sea3.shape
    sea_mean = (tot(sea1, l1, b1) + tot(sea2, l2, b2) + tot(sea3, l3, b3)) / (l1 * b1 + l2 * b2 + l3 * b3)

    l1, b1, c = veg1.shape
    l2, b2, c = veg2.shape
    l3, b3, c = veg3.shape
    l4, b4, c = veg4.shape
    veg_mean = (tot(veg1, l1, b1) + tot(veg2, l2, b2) + tot(veg3, l3, b3) + tot(veg4, l4, b4)) / (
                l1 * b1 + l2 * b2 + l3 * b3 + l4 * b4)

    l1, b1, c = lake.shape
    lake_mean = tot(lake, l1, b1) / (l1 * b1)

    l1, b1, c = buil.shape
    built_mean = tot(buil, l1, b1) / (l1 * b1)

    l, b, c = mumb.shape
    res_img = np.zeros((l, b))
    for i in range(l):
        for j in range(b):
            d1 = dist(sea_mean[0], mumb[i, j])
            d2 = dist(veg_mean[0], mumb[i, j])
            d3 = dist(lake_mean[0], mumb[i, j])
            d4 = dist(built_mean[0], mumb[i, j])
            m = min(d1, d2, d3, d4)
            if m == d1:
                res_img[i, j] = 0
            elif m == d2:
                res_img[i, j] = 128
            elif m == d3:
                res_img[i, j] = 75
            else:
                res_img[i, j] = 255

    if param == "eu":
        imsave('segmented_eu.png', res_img)
    else:
        imsave('segmented_man.png', res_img)
else:
    print("Unknown option")