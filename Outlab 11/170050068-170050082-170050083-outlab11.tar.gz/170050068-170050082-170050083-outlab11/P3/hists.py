import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib import rc

plt.figure(figsize=(25, 15))
rc('font', weight='bold')
f = open('survey_data.csv')

k = 0
Es = np.zeros(28)
Ni = np.zeros(28)
Do = np.zeros(28)
Ut = np.zeros(28)

for l in f:
    if k == 0:
        k = 1
    else:
        li = l.split(",")[1:]
        print(li)
        i = 0
        for topic in li:
            if topic == "Essential" or topic == "Essential\n":
                Es[i] = Es[i] + 1
                i = i + 1
            elif topic == "Nice to have" or topic == "Nice to have\n":
                Ni[i] = Ni[i] + 1
                i = i + 1
            elif topic == "Dont care one way or another" or topic == "Dont care one way or another\n":
                Do[i] = Do[i] + 1
                i = i + 1
            elif topic == "Utterly useless" or topic == "Utterly useless\n":
                Ut[i] = Ut[i] + 1
                i = i + 1


r = np.arange(28)

p1 = plt.barh(r, Es, color='green')
p2 = plt.barh(r, Ni, color='blue', left = Es )
p3 = plt.barh(r, Do, color='red', left = Es+Ni )
p4 = plt.barh(r, Ut, color='yellow',  left = Es+Ni+Do)


names = ["Shell Scripting - bash",	"Shell Scripting - csh/tsh/zsh","Unix System Tools - find/sort/grep...	",
         "Regular Expressions - python","Regular Expressions - awk, sed","Perl Programming","Python - base language, modules",
         "Python - os, sys, file, dict","Python - csv, pickle, hdf5",	"Python - numpy, scipy, scikit-learn",
         "Python - networking, requests","Java - language, package, class",	"Java - Concurrency","Java - Networking",
         "Java - JNI",	"Java - JDBC",	"Version Control - svn","Version Control - git",	"IDE - Eclipse","IDE - Jetbrains PyCharm, Java",
         "IDE - NetBeans",	"Build Environments - Make/AR/GDB",	"Client Side - HTML5, CSS, JQuery...",
         "Server Side - Servlets, Node.js, PHP","Latex, Gnuplot, Pyplot, Inkscape",	"Lex and Yacc","Erlang","MPI"]


# Custom X axis
plt.yticks(r, names, fontweight='bold')
plt.xticks()
plt.ylabel("Topics")
plt.xlabel("Opinions")

gp = mpatches.Patch(color='green', label='Essential')
bp = mpatches.Patch(color='blue', label='Nice to have')
rp = mpatches.Patch(color='red', label='Dont care one way or another')
yp = mpatches.Patch(color='yellow', label='Utterly useless')
plt.legend(handles=[gp,bp,rp,yp], loc='upper left')
# Show graphic
plt.savefig('hists.png')
