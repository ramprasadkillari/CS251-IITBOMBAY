import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc
import math
plt.figure(figsize=(25, 15))
rc('font', weight='bold')
f = open('survey_data.csv')

k = 0
Opin = np.zeros((4, 28))

for l in f:
    if k == 0:
        k = 1
    else:
        li = l.split(",")[1:]
        i = 0
        for topic in li:
            if topic == "Essential" or topic == "Essential\n":
                Opin[0][i] = Opin[0][i] + 1
                i = i + 1
            elif topic == "Nice to have" or topic == "Nice to have\n":
                Opin[1][i] = Opin[1][i] + 1
                i = i + 1
            elif topic == "Dont care one way or another" or topic == "Dont care one way or another\n":
                Opin[2][i] = Opin[2][i] + 1
                i = i + 1
            elif topic == "Utterly useless" or topic == "Utterly useless\n":
                Opin[3][i] = Opin[3][i] + 1
                i = i + 1
Ent = np.zeros(28)
ar = np.arange(28)

for i in range(28):
    p = [0, 0, 0, 0]
    p[0] = Opin[0][i]/13
    p[1] = Opin[1][i]/13
    p[2] = Opin[2][i]/13
    p[3] = Opin[3][i]/13
    entropy = 0
    for val in p:
        if val != 0:
            entropy = entropy - val*math.log2(val)
    Ent[i] = entropy

names = ["Shell Scripting - bash",	"Unix System Tools - find/sort/grep...	","Regular Expressions - python",
         "Python - base language, modules","Version Control - git","Build Environments - Make/AR/GDB",	 "Java - JNI",
         "Python - os, sys, file, dict","Latex, Gnuplot, Pyplot, Inkscape","Python - numpy, scipy, scikit-learn",
         "Server Side - Servlets, Node.js, PHP","IDE - Jetbrains PyCharm, Java","Erlang","IDE - NetBeans","Lex and Yacc",
         "MPI", "Client Side - HTML5, CSS, JQuery...","Java - JDBC", "Regular Expressions - awk, sed","Java - Networking",
         "Python - csv, pickle, hdf5","Java - language, package, class","IDE - Eclipse","Perl Programming",
         "Python - networking, requests","Java - Concurrency","Shell Scripting - csh/tsh/zsh","Version Control - svn"]

Ent.sort()
plt.barh(ar, Ent, align='center')
plt.yticks(ar, names, fontweight='bold')
plt.ylabel("Topics")
plt.xlabel("Entropy")

plt.savefig('contr.png')
