import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import csv
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
x = []
y = []
z = []
f = open('3dpd.out', 'r')
csv_reader = csv.reader(f, delimiter=',')
for row in csv_reader:
    x.append(float(row[0]))
    y.append(float(row[1]))
    z.append(float(row[2]))
ax.scatter(x, y, z, c='r', marker='o')

ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')

plt.show()
