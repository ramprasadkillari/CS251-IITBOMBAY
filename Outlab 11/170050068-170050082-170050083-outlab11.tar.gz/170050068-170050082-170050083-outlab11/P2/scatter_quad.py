import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import csv
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
x = []
y = []
z = []
f = open('3dpd.out', 'r')
csv_reader = csv.reader(f, delimiter=',')
for row in csv_reader:
    x.append(float(row[0]))
    y.append(float(row[1]))
    z.append(float(row[2]))
# ax.scatter(x, y, z, c='r', marker='o')
x1 = []
y1 = []
z1 = []
x2 = []
y2 = []
z2 = []
for i in range(len(z)):
    if z[i]*1.1 + x[i]**2 + y[i]**2 > 4.2:
        x1.append(x[i])
        y1.append(y[i])
        z1.append(z[i])
    else:
        x2.append(x[i])
        y2.append(y[i])
        z2.append(z[i])
ax.scatter(x1, y1, z1, c='b', marker='o')
ax.scatter(x2, y2, z2, c='r', marker='o')
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')

plt.show()
