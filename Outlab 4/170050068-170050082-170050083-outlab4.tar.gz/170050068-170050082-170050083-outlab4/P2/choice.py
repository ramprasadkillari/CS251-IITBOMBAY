import pickle
import random 
import string
from sys import argv
def fill_choice():
	pop=range(1,5001,1)
	choices=random.sample(pop,100)

	k=[]
	i = 0
	while i < 100:
		str = ''.join(random.sample(string.ascii_uppercase,random.randint(3,5)))
	
		if str in k:
			i=i
		else:
			k.append(str)
			i+=1
	return dict(zip(choices,k))



def ask_choice():
	dat=open(argv[1],'rb')
	data=pickle.load(dat)
	n=int (input("Enter Number: "))
	def func(k):
		if (k <= 7000 and k >= 5000):
			return k
		elif (k > 7000 or k < 5000):
			n=int (input("Number out of range 5000-7000 \nRe-enter Number: "))
			return func(n)
	n=int(func(n))

	state = 0
	for i in data.keys():
		for j in data.keys():
			if (i+j == n and i!=j):
				print(data[i],i,data[j],j)
				state=1
				break
			else:
				pass
		if state==1:
			break
	if state==0:
		for i in data.keys():
			for j in data.keys():
				if (i+j < n and i!=j):
					print(data[i],i,data[j],j)
					state=1
					break
				else:
					pass
			if state ==1:
				break
	if state ==0:
		print("Not Possible")
			

if (len(argv)==1):
	data= fill_choice()
	file=open('new_int.p','wb')
	pickle.dump(data,file,-1)
	file.close()
else:
	ask_choice()
