#! /usr/bin/python
import argparse
parser=argparse.ArgumentParser()
parser.add_argument("--check_prime",type=int,help="Prints Yes if the number is prime else No")
parser.add_argument("--range",nargs=2,help="prints all numbers between upper_bound and lower_bound",type=int) 
args=parser.parse_args()

def IsPrime(x):
    a=2
    if (x < 1 or x>1000):
       raise Exception
    else:
        while a < x:
            if ((x%a) == 0):
                return False;
            a+=1
        if (x!=1):    
            return True;
        else:
            return False;
           



def f(lower_bound,upper_bound):
    count=0
    if (lower_bound < 1 or upper_bound>1000):
        raise Exception 
    else:
         for i in range(lower_bound,upper_bound+1):
            if (IsPrime(i)):
                 count+=1   
    print (count)

if (args.check_prime and args.range):
    try:
        print(IsPrime(args.check_prime),end=" ")
        f(args.range[0],args.range[1])
    except Exception as error:
        print ("Error : Please enter a value between 1 and 1000 only")     
elif (args.check_prime):    
    try:
        print (IsPrime(args.check_prime))
    except Exception as error:
        print ("Error : Please enter a value between 1 and 1000 only")     
elif (args.range):            
    try:
        f(args.range[0],args.range[1])
    except Exception as error:
        print ("Error : Please enter a value between 1 and 1000 only")     
else:
    print ("Error : At least one of the following arguments are required: --check_prime, --range")      