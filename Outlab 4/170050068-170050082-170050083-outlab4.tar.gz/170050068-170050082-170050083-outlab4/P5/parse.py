import json
import csv
file=open('infinity_stones.json')
data=json.load(file)
f=csv.writer(open("infinity_stones.csv","w"),delimiter='|')
f.writerow(["Stone Name ","Stone Color","Containment Unit"])
for listod in data.values():
	for i in range(len(listod)):
	    f.writerow([listod[i]["Stone Name"],listod[i]["Stone Color"],listod[i]["Containment Unit"]])


