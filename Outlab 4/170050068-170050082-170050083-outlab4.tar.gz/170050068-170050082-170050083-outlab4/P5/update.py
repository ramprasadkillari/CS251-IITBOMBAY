import json
file=open('infinity_stones.json')
data=json.load(file)
f=open("update_stones.json","w")
newdata=data
for listod in newdata.values():
    for i in range(len(listod)):
	    listod[i]["Containment Unit"]="Infinity Gauntlet"

json.dump(newdata,f)