#! /usr/bin/python
import sys
import json
import random

#Following is the code for Problem 6 Task 1

def makeTeams(NoofTeams,NoofPlayers):
    try:
        if(NoofPlayers % NoofTeams == 0):
            result = NoofPlayers/NoofTeams
        else:
            raise ValueError

    except ValueError:
        print ("please remove " + str(NoofPlayers % NoofTeams) + " players to distribute them equally into all the teams")    

    except  ZeroDivisionError:
        print ("Cannot divide zero players")
t=int(sys.argv[1])
p=int(sys.argv[2])  
makeTeams(t,p)  

#The code for Problem 6 Task 1 ends here
#Following is the code for Problem 6 Task 2


class Error(Exception):
    pass

class Loyalty(Exception):
    pass    

playersdatabase={}
listofalljs=[]
i=1
while (i <= 1000):
    listofalljs.append(i)
    i+=1
jerseys=random.sample(listofalljs,100)
l=random.randint(1,10)

i=0
t=['A','B','C','D','E','F','G','H','I','J']
a=['A','B','C','D','E','F','G','H','I','J']

def checkteamname(x):
    for element in a:
        if (x==element):
            return True
    return False        

while (i<9):
    t.extend(a)
    i+=1
random.shuffle(t)   

i=0 

while (i<=99):
    playersdatabase.update({jerseys[i]:{'teamname':t[i],'loyalty':random.randint(1,10)}})
    i+=1

with open('data.json', 'w') as outfile:
    json.dump(playersdatabase, outfile)

def minloyaltyjersey(playersdatabase,teamn):
    loyal=12 
    for i in playersdatabase.keys():
        if (teamn == playersdatabase[i]['teamname']):
            lo=playersdatabase[i]['loyalty']
            if (loyal > lo):
                loyal = lo 
                jer=i   
            else:
                pass
    return jer
    
file=open("transfer.txt","r")
for line in file:
    l=line.split()
    try:
        if (not(int(l[1]) in playersdatabase.keys())):
            raise ValueError
        if (int(l[1]) > 1000 or int(l[1]) < 1):
            raise ValueError
        if (checkteamname(l[0])==False):
            raise Error   
        else:
            if (playersdatabase[int(l[1])]['loyalty'] <= 7):
                temp=playersdatabase[int(l[1])]['teamname']
                playersdatabase[int(l[1])]['teamname']=l[0]
                playersdatabase[minloyaltyjersey(playersdatabase,l[0])]['teamname']=temp
                with open('data.json', 'w') as outfile:
                    json.dump(playersdatabase, outfile)   
                print ("Transfer Complete")
            else:
                raise Loyalty         
    except Loyalty:
        print ("Try another transfer(Player too loyal)")             
    except Error:
        print ("Try another transfer(Wrong team name)")   
    except ValueError:    
        print ("Try another transfer(Wrong player number)")         

                    

            