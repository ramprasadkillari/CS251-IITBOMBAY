import numpy as kp
def ang_to_vec(ang):
	a=kp.deg2rad (ang)
	b=kp.cos(a)
	c=kp.sin(a)
	d=kp.stack((b,c),axis=-1)
	return d
def vec_to_ang(vec):
	a=vec[... ,0]
	b=vec[... ,1]
	c=kp.arctan2(b,a)
	d=kp.rad2deg(c)
	return d
