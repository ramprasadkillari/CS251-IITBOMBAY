import numpy as np
from sys import argv
from inc import ang_to_vec
from inc import vec_to_ang

inp_file=argv[1]
out_file=argv[2]
a2v = int (argv[3])
a=np.loadtxt(inp_file,delimiter=",")  
if (a2v == 0 and a.ndim ==1):
    np.savetxt(out_file,ang_to_vec(a),delimiter=",")
elif (a2v == 1 and a.ndim ==2):
	np.savetxt(out_file,vec_to_ang(a),delimiter=",")
else:
	exit(1)


