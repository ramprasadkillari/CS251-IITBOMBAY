import numpy

data = numpy.genfromtxt('info_day.csv', delimiter=',')

temp = []
for i in range(len(data)):
    if i == 0:
        continue
    else:
        temp.append(data[i][1])

hdty = []
for i in range(len(data)):
    if i == 0:
        continue
    else:
        hdty.append(data[i][2])

lght = []
for i in range(len(data)):
    if i == 0:
        continue
    else:
        lght.append(data[i][3])

co2 = []
for i in range(len(data)):
    if i == 0:
        continue
    else:
        co2.append(data[i][4])

print('Field       Mean              Std.Dev\n')
print('Temperature ' + str(numpy.mean(temp)) + '           ' + str(numpy.std(temp)) + '\n')
print('Humidity    ' + str(numpy.mean(hdty)) + ' ' + str(numpy.std(hdty)) + '\n')
print('Light       ' + str(numpy.mean(lght)) + ' ' + str(numpy.std(lght)) + '\n')
print('CO2         ' + str(numpy.mean(co2)) + '            ' + str(numpy.std(co2)) + '\n')

