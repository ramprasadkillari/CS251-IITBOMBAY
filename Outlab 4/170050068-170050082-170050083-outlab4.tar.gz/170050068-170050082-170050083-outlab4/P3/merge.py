import numpy

day_data = numpy.genfromtxt('info_day.csv', delimiter=',', dtype=None, encoding='UTF8')
night_data = numpy.genfromtxt('info_night.csv', delimiter=',', dtype=None, encoding='UTF8')

combined_data = numpy.array([['"Day"'], ['"Monday"'], ['"Tuesday"'], ['"Wednesday"'], ['"Thursday"'], ['"Friday"'], ['"Saturday"'], ['"Sunday"']], dtype='<U30')

for i in range(5):
    if i == 0:
        continue
    else:
        if i == 1:
            x = 1
        else:
            x = combined_data.shape[1]
        #print(i)
        combined_data = numpy.insert(combined_data, x, day_data[:, i], axis=1)
        combined_data = numpy.insert(combined_data, x, night_data[:, i], axis=1)

combined_data[0][1] = '"Temperature(Day)"'
combined_data[0][2] = '"Temperature(Night)"'
combined_data[0][3] = '"Humidity(Day)"'
combined_data[0][4] = '"Humidity(Night)"'
combined_data[0][5] = '"Light(Day)"'
combined_data[0][6] = '"Light(Night)"'
combined_data[0][7] = '"CO2(Day)"'
combined_data[0][8] = '"CO2(Night)"'

numpy.savetxt('info_combined.csv', combined_data, delimiter=',', fmt='%s')
# print(combined_data)
# print(day_data)