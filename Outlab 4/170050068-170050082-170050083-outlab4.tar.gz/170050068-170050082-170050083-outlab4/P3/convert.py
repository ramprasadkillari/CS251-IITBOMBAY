import numpy

data = numpy.genfromtxt('info_day.csv', delimiter=',', dtype=None, encoding='UTF8')


def ctof(c):
    f = c*(9/5) + 32
    return f


for i in range(len(data)):
    if i == 0:
        continue
    else:
        data[i][1] = str(ctof(float(data[i][1])))

numpy.savetxt('transformed.csv', data, delimiter=',', fmt="%s")


