class SetMenu:
    def __init__(self, menuitems):
        self.menuitems = set(menuitems)

    def __len__(self):
        return len(self.menuitems)

    def __str__(self):
        strng = ''
        for x in self.menuitems:
            strng = strng + str(x) + '\n'
        return strng
