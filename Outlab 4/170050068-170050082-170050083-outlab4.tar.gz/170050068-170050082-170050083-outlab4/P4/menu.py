class Menu:
    def __init__(self, items):
        self.items = items

    def __len__(self):
        return len(self.items)

    def __str__(self):
        strng = ''
        for x in self.items:
            strng = strng + str(x) + '\n'
        return strng
