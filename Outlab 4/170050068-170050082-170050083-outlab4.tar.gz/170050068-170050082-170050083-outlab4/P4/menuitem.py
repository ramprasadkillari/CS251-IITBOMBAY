class MenuItem:
    def __init__(self, name, cost, rating):
        self.name = name
        self.cost = cost
        self.rating = rating

    def __eq__(self, other):
        if self.name == other.name and self.cost == other.cost and self.rating == other.rating:
            return True
        else:
            return False

    def __str__(self):
        return 'Item: ' + self.name + ', Cost: ' + str(self.cost) + ', Rating: ' + str('%.6f'%(self.rating))

    def __hash__(self):
        return hash((self.name, self.cost, self.rating))

    def __lt__(self, other):
        return self.rating < other.rating or (self.rating == other.rating and self.cost < other.cost)
