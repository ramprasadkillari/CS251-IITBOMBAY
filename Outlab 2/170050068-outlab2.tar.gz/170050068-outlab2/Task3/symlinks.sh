
for var in $(find $1 -type l)
do
    if test -d $(realpath $var);then
	echo " $var $(realpath $var) @ 1 " >> $2
	else
   echo   "$var $(realpath $var) $(md5sum $var) 0" >> $2
     fi
    done
