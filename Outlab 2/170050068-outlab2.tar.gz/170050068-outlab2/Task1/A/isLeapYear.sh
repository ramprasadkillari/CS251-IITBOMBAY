

for year
do
    if [ $year -gt  0  2>/dev/null ]; then

	if (( $year % 4 == 0 ));then

	    if (( $year % 100 == 0 ));then

		if (( $year % 400 != 0 ));then
		    	echo "Not a leap year."
		    else
			echo "Leap Year!"
			fi
                 
                       else
		echo "Leap Year!"
		fi

	else
	    echo "Not a leap year."
	    fi
	   
    
    else
	echo "Invalid argument!"
	fi
      
	
done
