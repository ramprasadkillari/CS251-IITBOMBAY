

trap 'awk -f lure.awk $1 > loki.csv ; exit' 2

while (true)
do
    sleep 1
    done
    
