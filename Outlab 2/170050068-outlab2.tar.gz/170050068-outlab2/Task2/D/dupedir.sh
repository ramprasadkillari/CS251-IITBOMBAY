for var in $(find $1 -type f)
do
  echo $var | cut -d'/' -f-2
  if test -f  $(echo $var | cut -d'/' -f-2 )  ; then
      "
       cp $var $2
  else
     
    
      echo $(dirname $( echo $var | cut -d'/' -f2- ) )

      cd $2
 mkdir -p $( dirname  $( echo $var | cut -d'/' -f2- ) )
   cd ..
	   cp $var $2/$( echo $var | cut -d'/' -f2- )	  
	   fi
    done
