if [ -f $2 2>/dev/null ];then

    echo "Not copied $1"
    
else
    
    cp $1 $2
    echo "Copied $1"
    fi
