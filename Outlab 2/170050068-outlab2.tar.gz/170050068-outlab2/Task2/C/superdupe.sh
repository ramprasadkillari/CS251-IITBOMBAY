

if [ -f $2 2>/dev/null ];then

    echo "Not copied $1"
    
else

    mkdir -p $(dirname $2)
    cp $1 $2
    echo "Copied $1"
    fi
