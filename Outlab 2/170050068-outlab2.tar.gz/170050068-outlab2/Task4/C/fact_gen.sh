

fact(){
    if [ $1 == 0 ];then
       echo 1
       return
    else
	
	echo   " $1 * $(fact $(( $1 - 1 )) )"  | bc
	fi
}



if [ $1 -ge 0 2>/dev/null ];then
    fact $1

else
    echo "-"
    exit 1
    fi


