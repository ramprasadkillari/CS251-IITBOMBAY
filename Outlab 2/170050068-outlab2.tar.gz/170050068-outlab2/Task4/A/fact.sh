
fact(){
    if [ $1 == 0 ];then

	return 1
    else

  fact $(( $1 - 1 )) 
	 return $(( $1 * $? ))
	fi
}



if [ $1 -ge 0 2>/dev/null ];then
    fact $1
    echo $?
else
    echo "-"
    exit 1
    fi
