import java.util.*;
import java.io.*;
import java.lang.Math;

class Psumh extends Thread{

	int arr[];
	int p,sum;

	Psumh(int a[],int p){
		this.arr=a;
		this.p=p;
		this.sum=0;
	}
	public void run(){
		for(int i=0;i<p;i++)
			this.sum+=arr[i];

	}

}

public class PSum{

	static void sumofarr(int array[],int p){
		if (array.length==p){
			Psumh fin= new Psumh(array,p);
			//fin.sum=0;
			fin.start();
			try{fin.join();}
			catch(Exception ex){System.out.println("caught");}
			System.out.println(fin.sum);
		} 
		else
		{
			int size=array.length;
			int threads = size/p;
			Psumh runobj[] = new Psumh[threads];
			for(int i=0;i<threads;i++){
				runobj[i]=new  Psumh(Arrays.copyOfRange(array,i*p,p*(i+1)),p);
				//runobj[i].arr = Arrays.copyOfRange(array,i*p,p*(i+1));
				runobj[i].sum=0;
				runobj[i].start();
			}
			
			for(int i=0;i<threads;i++){
				try{
					runobj[i].join();
					//System.out.println(runobj[i].sum);
				}
				catch(Exception ex){System.out.println("caught");}

			}

			 int arr[] = new int[threads];
			for(int i=0;i<threads;i++){
				arr[i] = runobj[i].sum;
			}

			sumofarr(arr,p); 
		}
			
	}

	public static void main(String args[]){
		Scanner inp = new Scanner(System.in);
		int n = inp.nextInt();
		int p = inp.nextInt();
		int array[]=new int[(int)Math.pow(p,n)];

		for(int i=0;i<(int)Math.pow(p,n);i++)
			array[i] = inp.nextInt();
			//array[i] = i+1;
		sumofarr(array,p);
	}
	
		
}
