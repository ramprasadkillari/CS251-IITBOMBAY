import java.util.*;
import java.io.*;
public class FrequencyCollection{
	public static void main(String args[]){
		//File file = new File(args[0]);
		try{

		Scanner inp = new Scanner(new FileReader(args[0]));
		TreeMap<String, Integer> m = new TreeMap<String, Integer>();
		List<String> stopwords = Arrays.asList("and", "the" ,"is", "in", "at", "of", "his", "her", "him");
		while(inp.hasNext()){
			String a = inp.next().toLowerCase();

			//if (!(a=="and" || a=="the" || a=="is" || a=="in" || a=="at" || a=="of" || a=="his" || a=="her" || a=="him"))
//and, the is, in, at, of, his, her, him
  			if (!stopwords.contains(a)){
			Integer freq = m.get(a);
            m.put(a, (freq == null) ? 1 : freq + 1);}
        }

		// using for-each loop for iteration over Map.entrySet() 
        for (String entry : m.keySet())  
            System.out.println( entry + "," + m.get(entry)); 

		}

		
		catch(Exception ex){
			System.out.println("File not found");}
    } 

	
}