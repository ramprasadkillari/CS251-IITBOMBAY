// A Java program for a Client 
import java.util.Scanner;
import java.net.*; 
import java.io.*; 
  
public class DumbClient 
{ 
    // initialize socket and input output streams 
 
   public static void main(String args[]) 
    { 
      //  Client client = new Client("127.0.0.1", 5000); 
      // constructor to put ip address and port 
      // establish a connection 
        Socket socket = null;
        Scanner input = null;
        PrintStream out = null;
        try
        { 
          //  System.out.println("started");
            socket = new Socket("127.0.0.1", 8068); 
           // System.out.println("Connected");
            input  = new Scanner(socket.getInputStream());
            // sends output to the socket 
            out    = new PrintStream(socket.getOutputStream());

        } 
        catch(UnknownHostException u) 
        { 
            System.out.println(u); 
        } 
        catch(IOException i) 
        { 
            System.out.println(i); 
        } 
  
        // string to read message from input s

        out.println(args[0]);

        String msg2 = input.nextLine();
        System.out.println(args[0]);
        System.out.println(args[0]+msg2);
        // close the connection 
       /* try
        { 
            input.close(); 
            out.close(); 
            socket.close(); 
        } 
        catch(IOException i) 
        { 
            System.out.println(i); 
        } */
    } 
  
} 

