
// A Java program for a Server 
import java.util.Scanner;
import java.net.*; 
import java.io.*; 
  
public class EchoServer 
{ 
    //initialize socket and input stream 
   
    public static void main(String args[]) 
    { 
        // starts server and waits for a connection 
        try
        { 
            ServerSocket server = new ServerSocket(8068); 
           // System.out.println("Server started"); 
  
           // System.out.println("Waiting for a client ..."); 
  			while(true){
            Socket socket = server.accept(); 
           // System.out.println("Client accepted"); 
  
            // takes input from the client socket 
            Scanner in = new Scanner(socket.getInputStream());

            String msg = in.nextLine(); 

            System.out.println(msg);
  
            // reads message from client until "Over" is sent 
            
           // System.out.println("Closing connection"); 

            PrintStream out = new PrintStream(socket.getOutputStream());
          //  out.println(in+args[0]);
        out.println(args[0]);
    }
            // close connection 
          //  socket.close(); 
        } 
        catch(IOException i) 
        { 
            System.out.println(i); 
        } 
    } 
  
} 