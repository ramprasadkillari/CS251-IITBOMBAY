import sqlite3
import sys

conn = sqlite3.connect('ipl.db')
c = conn.cursor()



if 0 == int(sys.argv[2]):
	a = int(sys.argv[1])
	if(a==1):
		str1 = "DELETE FROM TEAM WHERE team_name = "+sys.argv[3]
		c.execute(str1)
	elif(a==2):
		str1="DELETE FROM PLAYER player_name = "+sys.argv[3]
		c.execute(str1)
	elif(a==3):
		str1="DELETE FROM MATCH WHERE match_id= "+sys.argv[3]
		c.execute(str1)

if 1 == int(sys.argv[2]):
	a = int(sys.argv[1])
	if(a==1):
		c.execute('''DELETE FROM TEAM WHERE team_id = ?''', (sys.argv[3],))
	elif(a==2):
		c.execute('''DELETE FROM PLAYER WHERE player_name= ?''', (sys.argv[3],))
	elif(a==3):
		c.execute('''DELETE FROM MATCH WHERE match_id=?''', (sys.argv[3],))

conn.commit()
conn.close()

#elif sys.argv[2]==1:


