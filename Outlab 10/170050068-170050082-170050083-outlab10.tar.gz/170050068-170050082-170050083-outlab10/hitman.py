import sqlite3

conn = sqlite3.connect('ipl.db')
c = conn.cursor()

c.execute('''SELECT player_id,player_name FROM PLAYER''')

l = c.fetchall()
d=[]
for i in l:
	x=i[0]
	a=6
	c.execute('''SELECT match_id FROM BALL_BY_BALL WHERE striker=?''',(x,))
	balls = len(c.fetchall())
	c.execute('''SELECT COUNT(*) FROM BALL_BY_BALL WHERE striker=? AND runs_scored=?''',(x,a,))
	noofsixes = c.fetchone()[0]
	if(balls!=0):
		fraction = (noofsixes*1.0)/balls 
		d.append((i[0],i[1],noofsixes,balls,fraction))
final = sorted(d, key=lambda x: x[4],reverse = True)
for j in final:
	print(j[0],j[1],j[2],j[3],j[4],sep=",")		