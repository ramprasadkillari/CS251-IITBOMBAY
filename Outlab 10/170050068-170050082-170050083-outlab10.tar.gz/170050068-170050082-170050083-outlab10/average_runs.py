import csv
import sqlite3

conn = sqlite3.connect('ipl.db')
c = conn.cursor()

c.execute('''SELECT venue_name,match_id FROM MATCH''')

l = c.fetchall()

d={}

for x,y in l:
	if (x == 'NULL'):
		pass
	elif (d.get(x) != None):	
		d[x].append(y)
	else:
		d[x]= [y]
ven_runs = []

for x in d.keys():
	sum=0
	y = d[x]
	for mid in y:	
		c.execute('''SELECT runs_scored FROM  BALL_BY_BALL WHERE match_id=?''',(mid,))
		runs = c.fetchall()
		for a in runs:
			sum+=a[0]
	matches = len(y)
	if(matches!=0):
		avg_runs = (sum*1.0)/matches
		ven_runs.append((x,avg_runs))

final = sorted(ven_runs, key=lambda x: x[1],reverse = True)

for el in final:
	print(el[0],el[1],sep=",")
		