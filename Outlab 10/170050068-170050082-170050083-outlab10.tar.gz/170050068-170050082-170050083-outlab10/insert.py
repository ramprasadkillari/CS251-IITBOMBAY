import csv
import sqlite3

conn = sqlite3.connect('ipl.db')
c = conn.cursor()

f = open('team.csv', 'r')
csv_reader = csv.reader(f, delimiter=',')

row_num = 0
for row in csv_reader:
    if row_num == 0:
        row_num = 1
    else:
        r = tuple(row)
        c.execute('''INSERT INTO TEAM VALUES (?,?)''', r)

f.close()

f1 = open('match.csv', 'r')
csv_reader = csv.reader(f1, delimiter=',')

row_num = 0
for row in csv_reader:
    if row_num == 0:
        row_num = 1
    else:
        r = tuple(row)
        c.execute('''INSERT INTO MATCH VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', r)

f1.close()

f2 = open('player.csv', 'r')
csv_reader = csv.reader(f2, delimiter=',')

row_num = 0
for row in csv_reader:
    if row_num == 0:
        row_num = 1
    else:
        r = tuple(row)
        c.execute('''INSERT INTO PLAYER VALUES (?,?,?,?,?,?)''', r)
f2.close()

f2 = open('player_match.csv', 'r')
csv_reader = csv.reader(f2, delimiter=',')

row_num = 0
for row in csv_reader:
    if row_num == 0:
        row_num = 1
    else:
        r = tuple(row)
        c.execute('''INSERT INTO PLAYER_MATCH VALUES (?,?,?,?,?,?,?)''', r)
f2.close()

f2 = open('ball_by_ball.csv', 'r')
csv_reader = csv.reader(f2, delimiter=',')

row_num = 0
for row in csv_reader:
    if row_num == 0:
        row_num = 1
    else:
        r = tuple(row)
        c.execute('''INSERT INTO BALL_BY_BALL VALUES (?,?,?,?,?,?,?,?,?,?,?)''', r)
f2.close()

conn.commit()
conn.close()