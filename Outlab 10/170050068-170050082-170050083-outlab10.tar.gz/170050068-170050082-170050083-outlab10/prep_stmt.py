import sqlite3
import sys

conn = sqlite3.connect('ipl.db')
c = conn.cursor()

a = int(sys.argv[1])
if(a==1):
	r=tuple(sys.argv[2:])
	c.execute('''INSERT INTO TEAM VALUES (?,?)''', r)
elif(a==2):
	r=tuple(sys.argv[2:])
	c.execute('''INSERT INTO PLAYER VALUES (?,?,?,?,?,?)''', r)
elif(a==3):
	r=tuple(sys.argv[2:])
	c.execute('''INSERT INTO MATCH VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', r)
elif(a==4):
	r=tuple(sys.argv[2:])
	c.execute('''INSERT INTO PLAYER_MATCH VALUES (?,?,?,?,?,?,?)''', r)
elif(a==5):
	r=tuple(sys.argv[2:])	
	c.execute('''INSERT INTO BALL_BY_BALL VALUES (?,?,?,?,?,?,?,?,?,?)''', r)

conn.commit()
conn.close()