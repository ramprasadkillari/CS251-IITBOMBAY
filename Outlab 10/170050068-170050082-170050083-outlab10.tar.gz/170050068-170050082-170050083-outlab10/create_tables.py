import sqlite3
import datetime	
mydb = sqlite3.connect('ipl.db')
c = mydb.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS TEAM (team_id int PRIMARY KEY, team_name varchar(30))''')
c.execute('''CREATE TABLE IF NOT EXISTS PLAYER (player_id int PRIMARY KEY, player_name varchar(30), dob timestamp ,batting_hand varchar(30), bowling_skill varchar(40), country_name varchar(30))''')
#c.execute('''CREATE TABLE PP(player_id int, team_id int, FOREIGN KEY (player_id) REFERENCES PLAYER(player_id), FOREIGN KEY (team_id) REFERENCES TEAM(team_id))''')
c.execute('''CREATE TABLE IF NOT EXISTS MATCH (match_id int PRIMARY KEY, season_year int, team1 int, team2 int, battedfirst int, battedsecond int, venue_name varchar(70), city_name varchar(30), country_name varchar(10), toss_winner int, match_winner int, toss_name varchar(5), win_type varchar(15), man_of_match int, win_margin int, FOREIGN KEY (team1) REFERENCES TEAM(team_id), FOREIGN KEY (team2) REFERENCES TEAM(team_id), FOREIGN KEY (battedfirst) REFERENCES TEAM(team_id), FOREIGN KEY (battedsecond) REFERENCES TEAM(team_id))''')
c.execute('''CREATE TABLE IF NOT EXISTS PLAYER_MATCH(playermatch_key bigint PRIMARY KEY, match_id int ,player_id int, batting_hand varchar(30), bowling_skill varchar(40), role_desc varchar(15), team_id int , FOREIGN KEY (player_id) REFERENCES PLAYER(player_id),FOREIGN KEY (team_id) REFERENCES TEAM(team_id) , FOREIGN KEY (match_id) REFERENCES MATCH(match_id) )''')
c.execute('''CREATE TABLE IF NOT EXISTS BALL_BY_BALL(match_id int , innings_no int, over_id int, ball_id int, striker_batting_position int, runs_scored int, extra_runs int, out_type varchar(30), striker int , non_striker int ,bowler int,FOREIGN KEY (striker) REFERENCES PLAYER(player_id),FOREIGN KEY (non_striker) REFERENCES PLAYER(player_id), FOREIGN KEY (match_id) REFERENCES MATCH(match_id), FOREIGN KEY (bowler) REFERENCES PLAYER(player_id), CONSTRAINT PK_BBB PRIMARY KEY (match_id,innings_no,over_id,ball_id))''')
mydb.commit()
mydb.close()
