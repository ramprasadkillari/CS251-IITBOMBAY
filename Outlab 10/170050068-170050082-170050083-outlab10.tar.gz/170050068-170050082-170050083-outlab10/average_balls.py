import csv
import sqlite3

conn = sqlite3.connect('ipl.db')
c = conn.cursor()

c.execute('''SELECT player_id,player_name FROM PLAYER''')

l = c.fetchall()

d=[]
for x,y in l:
	c.execute('''SELECT match_id FROM BALL_BY_BALL WHERE striker=?''',(x,))
	balls = len(c.fetchall())
	c.execute('''SELECT COUNT(DISTINCT match_id) FROM BALL_BY_BALL WHERE striker=?''',(x,))
	matches = c.fetchone()[0]
	if (matches != 0):
		avg_balls = (balls*1.0)/matches
		d.append((x,y,avg_balls))


final = sorted(d, key=lambda x: x[2],reverse = True)
count = 0
prev = -1
for el in final:
	if (count == 10):
		break
	elif (prev == el[2]):
		print(el[0],el[1],el[2],sep=",")
	else:
		count+=1
		print(el[0],el[1],el[2],sep=",")
		prev=el[2]
