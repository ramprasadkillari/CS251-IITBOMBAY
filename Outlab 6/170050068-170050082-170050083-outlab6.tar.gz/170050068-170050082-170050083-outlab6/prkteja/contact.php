<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="r.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>Contact</title>
    <style>
    body {
        width: 100%;
        height: 100%;
        max-height: 100%;
        margin: 0;
        padding: 0;
        background-image: url('c11.jpg');
        background-size:cover;
        background-repeat: no-repeat;
    }
    /* Add a black background color to the top navigation */
    .navbar {
	    overflow: hidden;
	    background-color: transparent;
	    font-family: verdana;
	    top: 0;
	    position: fixed;
	}

	#topbar {
		background-color: #000000;
		top: 0;
		padding: 16px 16px;
		width: 100%;
		display: block;
		overflow: hidden;
		position: fixed;
		font-size: 17px;
		opacity = 0;
	}

	.navbar a {
	    float: left;
	    font-size: 17px;
	    color: white;
	    text-align: center;
	    padding: 16px 16px;
	    font-weight: bold;
	    text-decoration: none;
	}
	.navbar a.active {
        background-color: white;
        color: black;
    }
    .dropdown {
	    float: left;
	    overflow: hidden;
	    opacity: 1;
	    position: fixed;
	    top: 53px;
	    left: 218px;
	}

	.dropdown .dropbtn {
	    font-size: 17px;    
	    border: none;
	    outline: none;
	    color: white;
	    padding: 16px 16px;
	    font-weight: bold;
	    background-color: inherit;
	    font-family: verdana;
	    margin: 0;
	    opacity: 1;
	    top: 0;
	    left: 218px;
	    position: fixed;
	}
	.dropdown-content {
	    display: none;
	    position: absolute;
	    background-color: #f9f9f9;
	    min-width: 160px;
	    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
	    z-index: 1;
	    opacity: 1;
	    position: fixed;
	}

	.dropdown-content a {
	    float: none;
	    color: black;
	    padding: 12px 16px;
	    text-decoration: none;
	    display: block;
	    text-align: left;
	    opacity: 1;
	}

	.dropdown-content a:hover {
	    background-color: #ddd;
	    color: white;
	}
	.navbar a:hover, .dropdown:hover .dropbtn {
	    background-color: red;
	}
	.dropdown:hover .dropdown-content {
	    display: block;
	}
</style>
</head>
<body>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div style="font-size: 60px; text-align: center; font-family: verdana; color: white; text-shadow: black 2px 2px;">
		<b>Contact info</b>
	</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div style="font-size: 30px; text-align: center; font-family: verdana; color: white;">
		Meet me at: Room no. 110, Hostel-3, IIT Bombay.
	</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div style="font-size: 30px; text-align: center; font-family: verdana; color: white;">
		Contact me through:
	</div> 
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div style="text-align: center">
		<a href="mailto:prkteja99@gmail.com">
			<img src="gmail.png" style="width: 100px; height: 100px; top: 500px; position: absolute; left: 43%">
		</a>
		
		<a href="https://www.facebook.com/rohit.keertiteja" style="display: inline;">
			<!-- <img src="white.png" style="width: 70px; height: 70px; left: 52.1%; top: 522px; position: absolute;"> -->
			<img src="fb.png" style="width: 93px; height: 93px; top: 500px; position: absolute;">
		</a>
		<!-- <a href="">
			<img src="">
		</a> -->
	</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>

	<div style="font-size: 60px; text-align: center; font-family: verdana; color: white; text-shadow: black 2px 2px;">
		<b>Feedback</b>
	</div>
	<div style="font-size: 30px; text-align: center; font-family: verdana; color: white;">
		Drop your comments:
	</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div style="text-align: center; font-family: verdana; font-size: 30px; color: white; font-weight: bold; text-shadow: black 2px 2px;">
		<form name="feedback" onsubmit="return validateForm()" method="post">
			Name:<br>
			<input type="text" name="name" style="width: 20%; padding: 12px 20px; margin: 8px 0; font-size: 20px; color: black;">
			<br>
			Comment:<br>
			<textarea cols="50"; rows="4"; name="comment" style="width: 20%; padding: 12px 20px; margin: 8px 0; font-size: 20px; color: black;"></textarea>
			<br><br>
			<input type="submit" value="Submit" style="width: 10%; padding: 12px 20px; font-size: 20px; color: black;">
		</form> 
	</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div id="topbar">
		&nbsp;
	</div>
	<div class="navbar">
	  <a href="index.php">ROHIT</a>
	  <a href="about.html">About me</a>
	  <div class="dropdown">
	    <button class="dropbtn">Academics 
	      <i class="fa fa-caret-down"></i>
	    </button>
	    <div class="dropdown-content">
	      <a href="timetable.html">Timetable</a>
	      <a href="courses.html">Courses</a>
	      <a href="projects.html">projects</a>
	    </div>
	  </div> 
	  <a href="#projects" style="color: transparent;">Academics <i class="fa fa-caret-down"></i></a>
      <a href="contact.php" class="active">Contact</a>
      <a href="team.html">CS251 team</a>
	</div>
	<?php
		$val1 = $_POST["name"];
		$val2 = $_POST["comment"];
		$val = "\n";
	    //$file1 = fopen("comment.txt", 'w') or die("unable to write to file");
	    $file1 = file_put_contents('comment.txt', $val1, FILE_APPEND | LOCK_EX);
	   	$file1 = file_put_contents('comment.txt', $val, FILE_APPEND | LOCK_EX);
	   	$file1 = file_put_contents('comment.txt', $val2, FILE_APPEND | LOCK_EX);
	   	$file1 = file_put_contents('comment.txt', $val, FILE_APPEND | LOCK_EX);
	   	$file1 = file_put_contents('comment.txt', $val, FILE_APPEND | LOCK_EX);

	    fclose($file1);
		
	?>
	<script>
		document.getElementById("topbar").style.opacity = "0";
		$(window).scroll(function() {
		  var scrollTop = $(this).scrollTop();

		  $('#topbar').css({
		    opacity: function() {
		      var elementHeight = $(this).height();
		      return 1 - (elementHeight - scrollTop) / elementHeight;
		    }
		  });
		});

		function validateForm() {
		    var x = document.forms["feedback"]["name"].value;
		    if (x == "") {
		        alert("Name must be filled out");
		        return false;
		    }
		    var y = document.forms["feedback"]["comment"].value;
		    if (y == "") {
		        alert("Please add comments");
		        return false;
		    }
		}


	</script>
</body>
</html>