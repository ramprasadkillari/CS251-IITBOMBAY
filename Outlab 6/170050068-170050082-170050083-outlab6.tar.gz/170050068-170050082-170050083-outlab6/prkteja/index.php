<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="r.png">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <title>Rohit-Home</title>
    <style>
    body {
        width: 100%;
        height: 100%;
        max-height: 100%;
        margin: 0;
        padding: 0;
        background-image: url('city.jpg');
        background-size:cover;
        background-repeat: no-repeat;
        background-color: #7c8d9f;
    }
    #intro {
        position: absolute;
        margin: 0;
        padding: 0;
        top: 200px;
        left: 700px;
        width: 800px;
        height: 400px;
        overflow: hidden;
    }
    #carousel {
        background-color: #7a8493;
        position: absolute;
        margin: 0;
        padding: 0;
        width: 100%;
        top:950px;
        opacity: 0;
    }
    #navbar {
      background-color: #ffffff;
      position: fixed;
      font-size: 17px;
      padding: 16px 16px;
      top: 0px;
      width: 100%;
      display: block;
      transition: top 0.3s;
      opacity: 0;
    }
    a:link {
        color: black; 
        background-color: transparent; 
        text-decoration: none;
    }

    a:visited {
        color: black;
        background-color: transparent;
        text-decoration: none;
    }

    a:hover {
        color: black;
        background-color: transparent;
        text-decoration: none;
    }

    a:active {
        color: black;
        background-color: transparent;
        text-decoration: none;
    }
    .zoom {
        padding: 0;
        background-color: transparent;
        transition: transform .2s; /* Animation */
        top: 200px; 
        left: 170px; 
        margin: 0 auto;
        position: absolute; 
    }

    .zoom:hover {
        transform: scale(1.05); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
    }
    a:hover {
        font-size: 103%;
    }
    /* Add a black background color to the top navigation */
    .topnav {
        background-color: transparent;
        opacity: 1;
        top: 0;
        overflow: hidden;
        position: fixed;
    }

    /* Style the links inside the navigation bar */
    .topnav a {
        float: left;
        background-color: transparent;
        color: #000000;
        text-align: center;
        padding: 16px 16px;
        text-decoration: none;
        font-weight: bold;
        font-family: verdana;
        font-size: 17px;
    }

    /* Change the color of links on hover */

    /* Add a color to the active/current link */
    .topnav a.active {
        background-color: #000000;
        color: white;
    }
    
    .dropdown {
        float: left;
        overflow: hidden;
        opacity: 1;
    }
    #home{
        opacity: 1;
    }

    .dropdown {
        float: left;
        overflow: hidden;
        opacity: 1;
        position: fixed;
        top: 53px;
        left: 218px;
    }

    .dropdown .dropbtn {
        font-size: 17px;    
        border: none;
        outline: none;
        color: black;
        padding: 16px 16px;
        font-weight: bold;
        background-color: inherit;
        font-family: verdana;
        margin: 0;
        opacity: 1;
        top: 0;
        left: 218px;
        position: fixed;
    }
    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #262626;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1;
        opacity: 1;
        position: fixed;
    }

    .dropdown-content a {
        float: none;
        color: white;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
        text-align: left;
        opacity: 1;
    }

    .dropdown-content a:hover {
        background-color: #ddd;
        color: white;
    }
    .topnav a:hover, .dropdown:hover .dropbtn {
        background-color: red;
        color: white;
    }
    .dropdown:hover .dropdown-content {
        display: block;
    }
    .container {
        background: black;
        position: relative;
    }
    .spacer {
        width: 0;
        height: 600px;
        float: left;
        clear: both;
    }
    .one {   
        width: 100%;
        /*height: 600px;*/
        position: relative; 
        float: left; 
    }
    .two {   
        width: 100%;
        /*height: 800px;*/
        position: relative; 
        float: left; 
        overflow: visible;
    }
    .latched { position: fixed; top: 0; left: 8px; right: 8px; width: auto; }
    </style>
</head>
<body> 

    <?php
    $file = fopen("count.txt", 'r') or die("unable to open file");
    $val = (int)fread($file,filesize("count.txt"));
    $val = $val + 1;
    fclose($file);

    $file1 = fopen("count.txt", 'w') or die("unable to write to file");
    fwrite($file1, $val);
    fclose($file1);
    echo $val;
    ?>


    <div class="spacer"></div>
    <div class="one"> 
        <div id="home">
            <div class="zoom">
            <a href="#carousel">
            <img src="me.jpeg" style="width: 400px; height: 400px">
            </a>
            </div>
            <div class="spacer"></div>
            <div id="intro">
                <div style="font-size: 100px; text-align: center; font-family: verdana">WELCOME</div>
                <div>&nbsp;</div>
                <div>&nbsp;</div>
                <div style="font-size: 50px; font-family: verdana; text-align: center;">
                    Hi, I am <div style="font-size:60px; display: inline;"><a href="about.html">Rohit Keerti Teja,</a></div>
                </div>
                <div>&nbsp;</div>
                <div style="font-size: 35px; font-family: verdana; text-align: center;">
                    
                                <!-- Trigger the modal with a button -->
                    <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" style="background-color: transparent; border: none; color: black;"><div style="font-size: 35px; font-family: verdana; text-align: center;">Undergraduate in CSE, IIT Bombay.</div>
                    </button>
                </div>
            </div>
        </div>
        <div>
            &nbsp;
        </div>
        <div>
            &nbsp;
        </div>
        <div>
            &nbsp;
        </div>
        <div class="spacer"></div>

        <!-- <div id="navbar">&nbsp;</div>
        <div id="mainmenu" class="topnav">
            <a class="active" href="#home">ROHIT</a>
            <a href="#about">About Me</a>
            <a href="#acad">Courses</a>
            <a href="#contact">Contact</a>
        </div> -->
    </div>
    <div class="two">
        
        <div id="carousel"> 
          <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
              <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
              <li data-target="#myCarousel" data-slide-to="1"></li>
              <li data-target="#myCarousel" data-slide-to="2"></li>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner">
              <div class="item active">
                <img  id="high" src="lab.jpg" style="width:100%; height: 900px">
              </div>

              <div class="item">
                <img  id="high" src="beach.jpg" style="width:100%; height: 900px">
              </div>
            
              <div class="item">
                <img  id="high" src="fiitjee.jpg" style="width:100%; height: 900px">
              </div>
            </div>

            <!-- Left and right controls -->
            <a class="left carousel-control" href="#myCarousel" data-slide="prev">
              <span class="glyphicon glyphicon-chevron-left"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#myCarousel" data-slide="next">
              <span class="glyphicon glyphicon-chevron-right"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
        </div>

    </div>



<!--/////////////////////////////////////////////////////////////////////-->
    <div id="myModal" class="modal fade" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Bio</h4>
          </div>
          <div class="modal-body">
            <p>biography</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>

      </div>
    </div>
    <div id="navbar">&nbsp;</div>
    <div class="topnav">
        <a class="active" href="index.php">ROHIT</a>
        <a href="about.html">About Me</a>
        <div class="dropdown">
            <button class="dropbtn">Academics 
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
              <a href="timetable.html">Timetable</a>
              <a href="courses.html">Courses</a>
              <a href="projects.html">Projects</a>
            </div>
        </div>
        <a href="#projects" style="color: transparent;">Academics <i class="fa fa-caret-down"></i></a>
        <a href="contact.php">Contact</a>
        <a href="team.html">CS251 team</a>
    </div>
    <div style="position: absolute;top: 0;right: 0;">No. of Views: <?php echo $val ?></div>
    <script type="text/javascript">
        // var h = window.innerHeight;
        // var imh = h - 33;
        // window.onload = function() {
        //     document.getElementById("high").style.height = window.innerHeight;
        // }


    window.onscroll = function() {scrollFunction()};

    function scrollFunction() {
      if (document.body.scrollTop > 70 || document.documentElement.scrollTop > 70) {
        document.getElementById("navbar").style.top = "0";
        document.getElementById("navbar").style.opacity = "1"
      } else {
        document.getElementById("navbar").style.top = "-50px";
        document.getElementById("navbar").style.opacity = document.body.scrollTop;
      }
    }  
    /////////////////
    $(window).scroll(function() {
          var scrollTop = $(this).scrollTop();

          $('#carousel').css({
            opacity: function() {
              var elementHeight = $(this).height();
              return 1 - (elementHeight - scrollTop) / elementHeight;
            }
          });
        });
    $(window).scroll(function() {
          var scrollTop = $(this).scrollTop();

          $('#home').css({
            opacity: function() {
              var elementHeight = screen.height;//$(this).height();
              return ((elementHeight - scrollTop) / elementHeight)*((elementHeight - scrollTop) / elementHeight)*((elementHeight - scrollTop) / elementHeight);
            }
          });
        });
    /////////////////
    (function($){
    /* Store the original positions */
    var d1 = $('.one');
    var d1orgtop = d1.position().top;
    var d2 = $('.two');
    var d2orgtop = d2.position().top;
    
    /* respond to the scroll event */
    $(window).scroll(function(){
        /* get the current scroll position */
        var st = $(window).scrollTop();

        /* change classes based on section positions */
        if (st >= d1orgtop) {
            d1.addClass('latched');
        } else {
            d1.removeClass('latched');
        }
        if (st >= d2orgtop) {
            d2.addClass('latched');
        } else {
            d2.removeClass('latched');
        }
    });

    })(window.jQuery);
    ///////////////////////////////////////////////////////////////////


    </script>
</body>
</html>