<!DOCTYPE html>
<html>
<head>	
	<title>Home</title>
	<link rel="shortcut icon" href="http://www.iconarchive.com/download/i76400/rafiqul-hassan/blogger/Home.ico">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<style>
	@import url('https://fonts.googleapis.com/css?family=Arima+Madurai:300');
	body{
	background-image: linear-gradient(to bottom,  rgba(255,168,76,0.6) 0%,rgba(255,168,76,0.6) 100%), url('https://images8.alphacoders.com/905/905172.jpg');
	background-position: top;
	background-blend-mode: soft-light;
	background-size: cover;
	overflow: hidden;
	height: 150%;
}



h1 {
	font-family: 'Arima Madurai', cursive;
	color: rgb(255,255,255,1);
	font-size: 6rem;
	letter-spacing: -3px;
	text-shadow: 0px 1px 1px rgba(255,255,255,0.6);
	position: top;
	z-index: 3;
}
p{
	font-family: 'Arima Madurai', cursive;
	color: rgb(255,255,255,1);
	font-size: 2rem;
	letter-spacing: -1px;
	text-shadow: 0px 1px 1px rgba(255,255,255,0.6);
	position: top;
	z-index: 3;
}
	ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: rgba(100,100,70,0.4);
	}

li {
    float: left;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

/* Change the link color to #111 (black) on hover */
li a:hover, .dropdown:hover .dropbtn {
    background-color: red;
}
li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {background-color: red;}

.dropdown:hover .dropdown-content {
    display: block;
}
	</style>
</head>

<body>	

	<?php
		$file = fopen("numberOfHits.txt",'r') or die("unable open file");
		$val = (int)fread($file,filesize("numberOfHits.txt"));
		$val=$val+1;
		fclose($file);

		$file1 = fopen("numberOfHits.txt",'w') or die("unable to open file");
		fwrite($file1,$val);
		fclose($file1);

		echo $val;
		?>
	
	<ul>
  <li><a href="index.php">Home</a></li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Academics</a>
    <div class="dropdown-content">
      <a href="Timetable.html">Timetable</a>
      <a href="Courses.html">Courses</a>
      <a href="projects.html">Projects</a>
    </div>
  </li>
  <li><a href="#about">Feedback</a></li>
  <li><a href="aboutme.html">About Me</a></li>
  <li><a href="cs251team.html">CS251 Team</a></li>
    </ul>
    <h1 class="w3-animate-zoom">Bonela Mahith</h1>
	<div class="w3-container">
		<button onclick="document.getElementById('id01').style.display='block'" class="w3-button w3-transparent w3-animate-left w3-hover-none w3-text-sand" style="font-size: 150%">Gamer/Music Lover/Coding Enthusiast</button>	
		<div id="id01" class="w3-modal">
			<div class="w3-modal-content">
				<header class="w3-container w3-teal">
					<span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-display-topright">&times;</span>
					<h2>My Biography</h2>
				</header>
				<div class="w3-container">
					<p>I am a CSE,Undergraduate student.My hobbies are gaming,listening to music and sleeping:P</p>
				</div>
				<footer class="w3-container w3-teal">
					<p>The End</p>
				</footer>
			</div>
		</div>
	</div>
	<img src="img.jpg" style="position: absolute;top: 35%;left: 1%;border-radius: 50%; width: 450px;height: 400px">
	<div style="position: absolute;color: white;top: 0;right: 0;font-size: 20px;">No. of Views: <?php echo $val ?></div>
</body>
</html>